<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
</head>
<body>

    <h2>Name: <?php echo $product->name; ?></h2>
    <p>descripation : <?php echo $product->des; ?></p>
    <p>MRP Price : <?php echo $product->mrp_price; ?></p>
    <p>selling price: <?php echo $product->selling_price;  ?></p>
    <p>short : <?php echo $product->short_desc;  ?></p>
    <p>quantoity Avaliable: <?php echo $product->qty_available; ?></p>
    <p>Image name: <?php echo $product->image; ?></p>
    <p>other Image name: <?php echo $product->other_image; ?></p>
    
</body>
</html>