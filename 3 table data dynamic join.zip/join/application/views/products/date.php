<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
       <h2 align="center" style="color: brown;">FILTER DATE ACCORDING</h2>
         <div align="center" >
            <form method="post" action="<?=base_url('backend/allDataDate');?>">
                  <input type="date" name="date">
                   <button type="submit">Submit</button>
            </form>
         </div>
        
</body>
</html>