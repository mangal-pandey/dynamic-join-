<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <div align="center">
          <table>
               <tr>
                    <th>#</th>
                   <th>Email</th>
                   <th>Mobile</th>
                   <th>Salary</th>
                   <th>Image</th>
                   <th>Date</th>
                  
               </tr>
                <?php
                  if($data!=0)
                   {
                     $i=1;
                   foreach($data as $key=>$da)
                    {
                 ?>
                <tr>
                    <td><?=$i++?></td>
                    <td><?=$da['email']?></td>
                    <td><?=$da['mobile']?></td>
                    <td><?=$da['salary']?></td>
                    <td><img src="<?=base_url('images/').$da['image']?>" style="width:30px;height:40px"></td>
                    <td><?=$da['date']?></td>
                   
                </tr>
                <?php
                    }

                }  
                ?>
          </table>
      </div>
</body>
</html>