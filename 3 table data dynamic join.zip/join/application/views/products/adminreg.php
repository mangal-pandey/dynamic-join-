<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="<?= base_url('join/store2')?>">
            <div>
                    <lable>Email</lable>
                    <input type="email" name="email" value="<?php echo set_value('email')?>" >
                   
            </div>
                <?php echo form_error('email'); ?>
                <br>
            <div>
                    <lable>Mobile</lable>
                    <input type="text" name="phone" value="<?php echo set_value('phone')?>"  >
            </div>
                <br>
                <?php echo form_error('phone'); ?>
                <br><br>
                <button type="submit">Submit</button>
</form>                

</body>
</html>