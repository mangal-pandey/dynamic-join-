<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
       <h2 align="center" style="color:darkred;">REGISTRATION</h2>
      <div align="center" style="border: black;">
           <form method="post" action="<?= base_url('join/store')?>">
           <div>
           <label>Full Name</label>
              <input type="text" name="fname" value="<?php echo set_value('fname'); ?>">
             <?php echo form_error('fname'); ?>
            </div>
            <br>

            <div>
                    <lable>Email</lable>
                    <input type="email" name="email" value="<?php echo set_value('email')?>" >
                   
                </div>
                <?php echo form_error('email'); ?>
                <br>
                <div>
                    <lable>Mobile</lable>
                    <input type="text" name="phone" value="<?php echo set_value('phone')?>"  >
                </div>
                <br>
                <?php echo form_error('phone'); ?>
                <br><br>

                <p>Education Data</p>
                <!-- <div>
                    <lable>User_id</lable>
                    <input type="text" name="user_id" value="<?php echo set_value('user_id')?>" >
                </div><br> -->

                <div>
                    <lable>Course Name</lable>
                    <input type="text" name="course_name" value="<?php echo set_value('course_name')?>" >
                </div>
                <?php echo form_error('course_name');?>
                <br>
                <div>
                    <lable>Collage Name</lable>
                    <input type="text" name="collage_name" value="<?php echo set_value('collage_name')?>" >
                </div>
                <?php echo form_error('collage_name');?>
                <br>
                <br>
                
                 <br>
                 
                <br>
                <p>Family information</p>

                <!-- <div>
                    <lable>Education id</lable>
                    <input type="text" name="education_id" value="<?php echo set_value('education_id')?>" >
                </div> -->

                <div>
                    <lable>Father Name</lable>
                    <input type="text" name="father_name" value="<?php echo set_value('father_name')?>" >
                </div>
                
                <?php echo form_error('father_name'); ?>
                <br>
                <div>
                    <lable>Mother Name</lable>
                    <input type="text" name="mother_name" value="<?php echo set_value('mother_name')?>" >
                </div>
                <?php echo form_error('mother_name'); ?>
                <br>
                
                <br>
                <div>
                    <lable>Mother Phone</lable>
                    <input type="text" name="mother_phone" value="<?php echo set_value('mother_phone')?>" >
                </div>
                <?php echo form_error('mother_phone'); ?>
                
                <br><br>
                

                <p>Address information</p>
                
                <!-- <div>
                    <lable>User_id</lable>
                    <input type="text" name="user_id" value="<?php echo set_value('user_id')?>" >
                </div> -->
                <br>

                <div>
                    <lable>Country</lable>
                    <input type="text" name="country" value="<?php echo set_value('country')?>" >
                </div><br>
                <?php echo form_error('country'); ?>
                
                <div>
                    <lable>City</lable>
                    <input type="text" name="city" value="<?php echo set_value('city')?>" >
                </div>
                <div><?php echo form_error('city'); ?></div>
                <br>
                <div>
                    <lable>Full Address</lable>
                    <input type="text" name="full_address" value="<?php echo set_value('full_address')?>" >
                </div>
                <?php echo form_error('full_address'); ?>
                <br>

                
                 <button type="submit">Submit</button>
           </form>
      </div>
      
    

      <script> src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>