<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
        <li>
           <?php 
               if(!isset($_SESSION['id']))
                 {
            ?>
             <a href="<?=base_url('/join');?>">Home</a>
             <?php
               }
             ?>

            <?php 
               if(! isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/adminloginpage');?>">Login</a>
             <?php
               }
             ?>
         
            <?php 
               if(! isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/registaion1');?>">Admin Registration</a>
             <?php
               }
             ?>



<?php 
               if(isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/product/product');?>">Add product</a>
             <?php
               }
             ?>


             <!-- <?php 
               if( isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('join/dashboad');?>">dashboad</a>
             <?php
               }
             ?> -->
          <!-- ////    -->
          <?php 
               if( isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/profile');?>">Profile</a>
             <?php
               }
             ?>

           
           <!-- <?php 
               if( isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/show');?>">Show</a>
             <?php
               }
             ?> -->

           <?php 
               if( isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/list');?>">User List</a>
             <?php
               }
             ?>
            <!-- //////  -->
             <?php 
               if( isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/remove1');?>">Remove</a>
             <?php
               }
             ?>

             <!-- <?php 
               if( isset($_SESSION['id']))
                 {
              ?>
             <a href="<?=base_url('/join/datefilter');?>">DateFilter</a>
             <?php
               }
             ?> -->

          <!-- ///// -->
           <?php  
              if(isset($_SESSION['id']))
               {
            ?>
             <a style="margin-left:90%;" href="<?=base_url('/join/adminlogout');?>">Adminlogout</a>
             <?php
               }
             ?>
        </li>
    </ul>
    <?php
      if(isset($_SESSION['message']))
       {
      ?>
        <p><?php echo $_SESSION['message']; ?></p>
      <?php
       }
    ?>  

</body>
</html>