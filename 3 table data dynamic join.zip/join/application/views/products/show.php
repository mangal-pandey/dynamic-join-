<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <h2 align="center" style="color: crimson;">show</h2>
       <div align="center">
            <table>
                 <tr>
                  <th>id</th>
                 <th>Name</th>
                     <th>Email</th>
                     <th>Mobile</th>
                     <th>country</th>
                     <th>Father Name</th>
                     <th>Mother Name</th>
                     <th>full address</th>
                     <th>city</th>
                     <th>collage name</th>
                     <th>course name</th>
                 </tr>
                 <?php
                    foreach($data as $key=>$data1)
                    {
                     
                         ?>
                 
                  <tr>
                    <td><?=$data1->id?></td>
                  <td><?=$data1->name?></td>
                  <td><?=$data1->email?></td>
                  <td><?=$data1->phone?></td>
                  <td><?=$data1->country?></td>
                  <td><?=$data1->father_name?></td>
                  <td><?=$data1->mother_name?></td>
                  <td><?=$data1->full_address?></td>
                  <td><?=$data1->city?></td>
                  <td><?=$data1->collage_name?></td>
                  <td><?=$data1->course_name?></td>
                </tr>

                  <?php
                    }
                        
                        
                  ?>

            </table>
       </div>
    
</body>
</html>