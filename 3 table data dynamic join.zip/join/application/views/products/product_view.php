<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Page</title>
</head>
<body>

    <div class="product-container">
        <h1>Product Name</h1>

        <img src="<?php echo base_url('assets/images/product-main-image.jpg'); ?>" alt="Product Image" class="product-image">

        <div class="description">
            <h2>Description:</h2>
            <p>This is a short description of the product. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget felis vel urna dapibus vestibulum.</p>
        </div>

        <div class="additional-images">
            <h2>Additional Images:</h2>
            <img src="<?php echo base_url('assets/images/'); ?>" alt="Additional Image 1">
            <!-- Add more images as needed -->
        </div>
    </div>

</body>
</html>
