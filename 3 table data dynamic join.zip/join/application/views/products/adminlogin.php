<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <h2 align="center" style="color: darkred;">Login</h2>
      <div align="center" style="border: black;">
           <form method="post" action="<?= base_url('join/Adminlogindata')?>">
                <div>
                    <lable>Email</lable>
                    <input type="text" name="email" >
                    
                </div>
                <br>
                <div>
                    <lable>mobile</lable>
                    <input type="text" name="mobile" >
                    
                </div>
                <br>
                <!-- <div>
                    <lable>Password</lable>
                    <input type="text" name="password">
                </div> -->
                <br>
                 <button type="submit">Submit</button>
           </form>
      </div>
</body>
</html>