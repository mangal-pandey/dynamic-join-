<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <h2 align="center" style="color: brown;">PROFILE</h2>
         <div align="center">
             <table>
                 <tr>
                 <th>Email</th>
                     <th>Mobile</th>
                     <th>name</th>
                     
                     <!-- <th>country</th>
                     <th>state</th>
                     <th>city</th>
                     <th>pincode</th>
                     <th>full address</th>
                     <th>father_name</th>
                     <th>mother_name</th>
                     <th>father_occupation</th>
                     <th>mother_occupation</th>
                     <th>mother salary</th>
                     <th>father salary</th> -->
                 </tr>
                  <tr>
                      <td><?=$data['email']?></td> 
                      <td><?=$data['phone']?></td> 
                      <td><?=$data['name']?></td>
                       
                     
                      
                  </tr>
             </table>
         </div>
      
</body>
</html>