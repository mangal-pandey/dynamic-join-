<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
       <h2 align="center" style="color:darkred;">Product add</h2>
      <div align="center" style="border: black;">
           <form method="post" action="<?= base_url('product/store')?>">
           
           
           
           <p>Product Details</p>
            <br>
            <div>
                    <lable>Product Name</lable>
                    <input type="text" name="name" value="<?php echo set_value('name')?>" >
                </div>
                <?php echo form_error('name');?>
                <br>
           
                

                
                <!-- <div>
                    <lable>User_id</lable>
                    <input type="text" name="user_id" value="<?php echo set_value('user_id')?>" >
                </div><br> -->

                <div>
                    <lable>MRP Price</lable>
                    <input type="text" name="mrp_price" value="<?php echo set_value('mrp_price')?>" >
                </div>
                <?php echo form_error('mrp_price');?>
                <br>
                <div>
                    <lable>Selling Price</lable>
                    <input type="text" name="selling_price" value="<?php echo set_value('selling_price')?>" >
                </div>
                <?php echo form_error('selling_price');?>
                <br>
                <br>
                
                 <br>
                 <div>
                    <lable>Short Description</lable>
                    <input type="text" name="short_desc" value="<?php echo set_value('short_desc')?>" >
                </div>
                <?php echo form_error('short_desc');?>
                <br>
                <br>
                
                <p>Product Stock</p>
                <div>
                    <lable>Quentity available</lable>
                    <input type="text" name="qty_available" value="<?php echo set_value('qty_available')?>" >
                </div>
                
                <?php echo form_error('qty_available'); ?>
                <br>
                <div>
                    <lable>Description</lable>
                    <input type="text" name="des" value="<?php echo set_value('des')?>" >
                   
                </div>
                <?php echo form_error('des'); ?>
                <br>
                <div>
                    <lable>Image</lable>
                    <input type="file" name="userfile" value="<?php echo set_value('image')?>"  >
                </div>
                <br>
                <?php echo form_error('image'); ?>
                <br><br>
               
                <br>
                <div>
                    <lable>Other Image</lable>
                    <input type="file" name="userfile1" value="<?php echo set_value('other_image')?>"  >
                </div> 
                <br>
                <?php echo form_error('other_image'); ?>
                <br><br>
                <div>
                    <lable>category</lable>
                    <input type="text" name="category" value="<?php echo set_value('category')?>" >
                   
                </div>
                <?php echo form_error('category'); ?>
                 <button type="submit">Submit</button>
           </form>
      </div>
      
    

      <script> src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>