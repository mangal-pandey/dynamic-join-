

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboad</title>
</head>
<body>
<h2>Dashboard</h2>
    
    <!-- Check-In Button -->
    <?php if ($can_checkin): ?>
        <form action="<?php echo base_url('join/checkIn); ?>" method="post">
            <button type="submit">Check In</button>
        </form>
    <?php endif; ?>

    <!-- Check-Out Button -->
    <?php if ($can_checkout): ?>
        <form action="<?php echo base_url('join/checkOut'); ?>" method="post">
            <button type="submit">Check Out</button>
        </form>
    <?php endif; ?>
</body>
</html>
