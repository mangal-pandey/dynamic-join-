<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <h1 align="center" style="color:darkred">REMOVE ACCOUNT PLEASE ENTER MOBILE NUMBER</h1>
      <div>
         <form method="post" action="<?=base_url('join/delete');?>">
             
            <!-- <lable>Mobile</lable>
              <input type="text" name="mobile">
               <br> -->
               <lable>id</lable>
              <input type="text" name="id">
               <br>
               <!-- <lable>user Info id</lable>
              <input type="text" name="id">
              <br>
              <lable>Family Id</lable>
              <input type="text" name="id"> -->
              <br>
               <button type="submit">submit</button>
         </form>
      </div> 
</body>
</html>