<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <h2 align="center" style="color: crimson;">List</h2>
       <div align="center">
            <table>
                 <tr>
                     <th>id</th>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Mobile</th>
                    
                     
                 </tr>
                 <?php
                    foreach($data as $key=>$datat)
                      {
                         if($datat['id']!=$_SESSION['id'])
                          {
                  ?>
                  <tr>
                          <td><?=$datat['id']?></td>  
                          <td><?=$datat['name']?></td>
                          <td><?=$datat['email']?></td> 
                          <td><?=$datat['phone']?></td> 
                           
                      </tr>
                  <?php
                          }
                      }

                  ?>
                
            </table>
       </div>
    
</body>
</html>