<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>

    <h2>User Dashboard</h2>
<form>
    <!-- Check-In Button -->
    <?php if ($can_checkin): ?>
        <form action="<?php echo base_url('dashboardcontroller1/checkIn'); ?>" method="post">
            <button type="submit">Check In</button>
        </form>
    <?php endif; ?>

    <!-- Check-Out Button -->
    <?php if ($can_checkout): ?>
        <form action="<?php echo base_url('dashboardcontroller1/checkOut'); ?>" method="post">
            <button type="submit">Check Out</button>
        </form>
    <?php endif; ?>

    <!-- User Attendance Information -->
    <?php if ($user_attendance): ?>
        <p>Check-In Time: <?php echo $user_attendance->checkin_time; ?></p>
        <p>Check-Out Time: <?php echo $user_attendance->checkout_time; ?></p>
        <p>Date: <?php echo $user_attendance->date; ?></p>
    <?php endif; ?>

</body>
</html>
