<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>

    <!-- Check-In Button -->
    <?php if (!$attendance || !$attendance->checkin_time): ?>
        <form action="<?php echo base_url('dashboardcontroller/checkIn'); ?>" method="post">
            <button type="submit">Check In</button>
        </form>
    <?php endif; ?>

    <!-- Check-Out Button -->
    <?php if ($attendance && $attendance->checkin_time && !$attendance->checkout_time): ?>
        <form action="<?php echo base_url('dashboardcontroller/checkOut'); ?>" method="post">
            <button type="submit">Check Out</button>
        </form>
    <?php endif; ?>

    <!-- Date and Time Information -->
    <?php if ($attendance): ?>
        <p>Last Check-In Time: <?php echo $attendance->checkin_time; ?></p>
        <p>Last Check-Out Time: <?php echo $attendance->checkout_time; ?></p>
    <?php endif; ?>


    <!-- All Users Attendance -->
    <!-- <h3>All Users Attendance</h3>
    <table border="1">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Check-In Time</th>
                <th>Check-Out Time</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($all_user_attendance as $attendance): ?>
                <tr>
                    <td><?php echo $attendance->user_id; ?></td>
                    <td><?php echo $attendance->name; ?></td>
                    <td><?php echo $attendance->checkin_time; ?></td>
                    <td><?php echo $attendance->checkout_time; ?></td>
                    <td><?php echo $attendance->date; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table> -->

</body>
</html>
