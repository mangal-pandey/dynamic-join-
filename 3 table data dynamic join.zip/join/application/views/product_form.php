<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
</head>
<body>

    <?php echo form_open_multipart('productcontroller/add_product'); ?>

    <label >Product Name:</label>
    <input type="text" name="name" required />

    <br>
    <br>
    <label >Product Description:</label>
    <textarea name="des" required></textarea>

    <br>
    <br>

    <label >short dec :</label>
    <input type="text" name="short_desc" required />

    <br><br>
    <label >category:</label>
    <input type="text" name="category" required />
    <br>
    <br />
    <br><br>
    <label >mrp:</label>
    <input type="text" name="mrp_price" required />
    <br>
    <label >Selling Price:</label>
    <input type="text" name="selling_price" required />

    <br>
    <br>
    <label>Product Stock Quantity:</label>
    <input type="text" name="qty_available" required />

    <br>
    <br>
    <label >Product Image:</label>
    <input type="file" name="userfile" size="20" />

    <br><br>
    <label >Other Image:</label>
    <input type="file" name="userfile1" size="20" />

    <br><br>

    <input type="submit" value="Add Product" />

    </form>

</body>
</html>
