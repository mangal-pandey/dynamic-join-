<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance_model extends CI_Model {

    
    public function checkIn($user_id) {
        date_default_timezone_set('Asia/Kolkata');
        $itime=time();
        $data = array(
            'user_id' => $user_id,
            'checkin_time' => date('Y-m-d h:i:s',$itime),
            'date' => date('Y-m-d')
        );
        $this->db->insert('attendance', $data);
    }

    public function checkOut($user_id) {
        date_default_timezone_set('Asia/Kolkata');
        $itime=time();
        $this->db->set('checkout_time', date('Y-m-d h:i:s',$itime));
        $this->db->where('user_id', $user_id);
        $this->db->where('date', date('Y-m-d'));
        $this->db->update('attendance');
    }

    public function getAttendance($user_id) {
        date_default_timezone_set('Asia/Kolkata');
        $itime=time();
        $this->db->select('checkin_time, checkout_time, date');
        $this->db->where('user_id', $user_id);
        $this->db->where('date', date('Y-m-d',$itime));
        $query = $this->db->get('attendance');
        return $query->row();
    }
}
