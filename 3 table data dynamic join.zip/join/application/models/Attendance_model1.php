<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance_model1 extends CI_Model {

    public function canCheckIn($user_id) {
        // Check if the user can perform check-in (only once per day)
        
        $this->db->where('user_id', $user_id);
        $this->db->where('date', date('Y-m-d'));
        $query = $this->db->get('attendance');

        return $query->num_rows() === 0;
    }

    public function checkIn($user_id) {
        // Perform check-in logic
        $data = array(
            'user_id' => $user_id,
            'checkin_time' => date('Y-m-d H:i:s'),
            'date' => date('Y-m-d')
        );
        $this->db->insert('attendance', $data);
    }

    public function canCheckOut($user_id) {
        // Check if the user can perform check-out (only if checked-in on the same day)
        $this->db->where('user_id', $user_id);
        $this->db->where('date', date('Y-m-d'));
        $this->db->where('checkout_time IS NULL', null, false); // Check if checkout_time is NULL
        $query = $this->db->get('attendance');

        return $query->num_rows() > 0;
    }

    public function checkOut($user_id) {
        // Perform check-out logic
        $this->db->set('checkout_time', date('Y-m-d H:i:s'));
        $this->db->where('user_id', $user_id);
        $this->db->where('date', date('Y-m-d'));
        $this->db->update('attendance');
    }

    public function getUserAttendance($user_id) {
        // Retrieve attendance data for a specific user
        $this->db->select('checkin_time, checkout_time, date');
        $this->db->where('user_id', $user_id);
        $this->db->where('date', date('Y-m-d'));
        $query = $this->db->get('attendance');
        return $query->row();
    }
}
