<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CheckInOut_Model extends CI_Model {

    public function canCheckIn($id) {
        // Check if the user can perform check-in (only once per day)
        $this->db->where('id', $id);
        $this->db->where('check_in < CURDATE()');
        $query = $this->db->get('attendance');

        return $query->num_rows() > 0;
    }

    public function checkIn($id) {
        // Perform check-in logic
        $data = array(
            'stetus' => 'checked-in',
            'check_in' => date('Y-m-d H:i:s')
        );
        $this->db->where('id', $id);
        $this->db->update('attendance', $data);
    }

    public function canCheckOut($id) {
        // Check if the user can perform check-out (only if checked-in on the same day)
        $this->db->where('id', $id);
        $this->db->where('stetus', 'checked-in');
        $this->db->where('check_in >= CURDATE()');
        $query = $this->db->get('attendance');

        return $query->num_rows() > 0;
    }

    public function checkOut($id) {
        // Perform check-out logic
        $data = array(
            'stetus' => 'checked-out',
            'check_out' => date('Y-m-d H:i:s')
        );
        $this->db->where('id', $id);
        $this->db->update('attendance', $data);
    }
}
