<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductModel extends CI_Model {

    public function insert_product($data) {
        $this->db->insert('product_detail', $data);
        return $this->db->insert_id();
    }

    public function insert_price($data) {
        $this->db->insert('product_price', $data);
        return $this->db->insert_id();
    }

    public function insert_stock($data) {
        $this->db->insert('product_stock', $data);
        return $this->db->insert_id();
    }

    public function get_product_details($product_id) {
        $this->db->select('product_detail.*, product_price.*, product_stock.*');
        $this->db->from('product_detail');
        $this->db->join('product_price', 'product_detail.id = product_price.product_id');
        $this->db->join('product_stock', 'product_detail.id = product_stock.product_id');
        $this->db->where('product_detail.id', $product_id);
        $query = $this->db->get();

        return $query->row();
    }
}
