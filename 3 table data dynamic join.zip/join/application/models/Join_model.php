<?php
class Join_model extends CI_Model{



public function emailCheck($table,$email)
{
    $this->db->where('email',$email);
   $var= $this->db->get($table);
   return $var->num_rows();
}

public function mobileCheck($table,$mobile)
{
  $this->db->where('phone',$mobile);
  $var= $this->db->get($table);
  return $var->num_rows();
}



public function insert_entry()
    {
      $this->db->trans_start();
      $this->db->select('user1.*,address1.*,education.*,family.*')
      ->form('user1')
      ->join('address1','address1.user_id=user1.id')
      ->join('education','education.user_id=user1.id')
      ->join('family','family.user_id=education.id')
      ->get()->result_array();


      }

// public function insert_entry1()
//     {
//       $this->db->trans_start();
//       $this->db->select('product_detail.*,product_price.*,product_stock.*')
//       ->form('product_detail')
//       ->join('product_price','product.product_id=product.id')
//       ->join('product_stock','product.product_id=product_detail.id')
//       ->get()->result_array();
//       }



public function add($table,$data){
         $this->db->insert($table,$data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
      }



public function loginCheck($data)
           {
              $this->db->where($data);
              $jk=  $this->db->get('user1')->result_array();
               return $jk[0]['id'];

           }
           
           
public function adminloginCheck($data)
           {
              $this->db->where($data);
              $j=  $this->db->get('admins')->result_array();
               return $j[0]['id'];

           }
       
      
public function profileData($id)
        {
           
            $this->db->where('id',$id);
            
            $data=$this->db->get('user1');
            $newdata=$data->result_array();
            return  $newdata;
           
        } 
public function showone(){
              $this->db->select('user1.*,address1.*,family.*,education.*');
              $this->db->from('user1');
              $this->db->join('address1','address1.user_id=user1.id');
              $this->db->join('family','family.user_id=user1.id');
              $this->db->join('education','education.user_id=user1.id');
              $query=$this->db->get();
              return $result=$query->result();

             }
        //admin show one      
// public function showone1(){
//               $this->db->select('product_detail.*,product_price.*,product_stock.*');
//               $this->db->from('product_detail');
//               $this->db->join('product_price','product.product_id=product.id');
//               $this->db->join('product_stock','product.product_id=product_detail.id');
//               $query=$this->db->get();
//               return $result1=$query->result();

//              }             
public function allData()
            {
                $this->db->select('*');
                $this->db->order_by('id','asc');
              $mp= $this->db->get('user1');
                $m=$mp->result_array();
               return $m;

            } 

public function removeData($id)
              {
                 $this->db->where('id',$id);
                 $check= $this->db->delete('user1'); 
                  return $check; 
                 
              }
public function removeData1($id)
              {
                 $this->db->where('id',$id);
                 $check1= $this->db->delete('admins'); 
                  return $check1; 
                 
              }
            
public function fileupload($filenm, $foldername){


	
                if(!empty($_FILES[$filenm]['name'])){
                  $new_image_name = time().str_replace(str_split(' ()\\/,:*?"<>|'), '', 
            
                        $_FILES[$filenm]['name']);
                   $config['upload_path'] = './'.$foldername.'/';
                        $config['allowed_types'] = 'mp4|3gp|mpeg|jpg|jpeg|png|gif|pdf';
                        $config['file_name'] = $new_image_name;
                    $config['overwrite'] = TRUE;
                    $config['max_width']  = '0';
                    $config['max_height']  = '0';
                        $this->load->library('upload',$config);
                        $this->upload->initialize($config);
                        if($this->upload->do_upload($filenm)){
                            $uploadData = $this->upload->data();
                            $config['image_library'] = 'gd2'; 
                            $config['source_image'] = $uploadData['full_path'];
                    $config['create_thumb'] = TRUE;
                    $config['maintain_ratio'] = TRUE;
                    $config['width']         = 300;
                    $config['height']       = 300;
                            $this->load->library('image_lib', $config);
                            if (!$this->image_lib->resize()) {
                            }
                            $picture = $uploadData['file_name'];
                        }else{
                            $picture = '';
                        }
                } else {
                  $picture = '';
                }
            
                return $picture;
            
              }
}

      



?>