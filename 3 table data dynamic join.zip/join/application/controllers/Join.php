<?php

    class Join extends CI_Controller{



public function __construct(){
            parent:: __construct();
            $this->load->library('form_validation'); 
            $this->load->model('join_model');
  
          }
public function index(){
              $this->load->view('products/index');
          }

public function registaion(){
            $this->load->view('products/index');
            $this->load->view('products/reg');
          } 



          // -------------User page ---------------------------

public function store(){
            if($this->input->post()){
              $this->load->library('form_validation');
              $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
            //user info
            $this->form_validation->set_rules('fname','Full Name','trim|required');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email'); 
            $this->form_validation->set_rules('phone', 'mobile', 'trim|required');
            
            //address info 
            // $this->form_validation->set_rules('user_id','User id','trim|required');
            $this->form_validation->set_rules('country','Country','trim|required');
            $this->form_validation->set_rules('city','City','trim|required');
            $this->form_validation->set_rules('full_address','Address','trim|required');
            
            
            //family info
            $this->form_validation->set_rules('father_name','Father Name','trim|required');
            $this->form_validation->set_rules('mother_name','Mother Name','trim|required');
         
            // $this->form_validation->set_rules('education_id','Education id','trim|required');
            $this->form_validation->set_rules('mother_phone','Mother phone','trim|required');

            //education info
            // $this->form_validation->set_rules('user_id','User id','trim|required');
            $this->form_validation->set_rules('course_name','Course Name','trim|required');
            $this->form_validation->set_rules('collage_name','Collage Name','trim|required');
            

            if($this->form_validation->run() == FALSE){
                 

              $this->session->set_flashdata('message','Please Insert Right Data');
                 
                   
            }else{

             
             $email=$_POST['email'];
             $mobile=$_POST['phone'];
             

               
                  if($this->join_model->emailcheck('user1',$email)) 
                    {
                      $this->session->set_flashdata('message','This Email Earley Register');
                        return redirect('join/registaion');
                    }    
             else if($this->join_model->mobilecheck('user1',$mobile)) 
                    {
                      $this->session->set_flashdata('message','This Mobile Earley Register');
                        return redirect('join/registaion');
                    }    
                   
                        //user data
                $datat=array();

                $datat['name'] = $this->input->post('fname');
                $datat['email'] = $this->input->post('email');
                $datat['phone'] = $this->input->post('phone');
                


                $result=$this->join_model->add('user1',$datat);
                

                //address data
                $data1=array();

                $data1['country'] = $this->input->post('country');
                $data1['user_id']=$result;
                $data1['city'] = $this->input->post('city');
                $data1['full_address'] = $this->input->post('full_address');
                
                

                $result1=$this->join_model->add('address1',$data1);

                //family info
                $data2=array();
                $data2['father_name'] = $this->input->post('father_name');
                $data2['mother_name'] = $this->input->post('mother_name');
                $data2['mother_phone']=$this->input->post('mother_phone');
                $data2['user_id']=$result;




                $result2=$this->join_model->add('family',$data2);
                //education data
                $data3=array();

                $data3['user_id']=$result;
                $data3['course_name'] = $this->input->post('course_name');
                $data3['collage_name'] = $this->input->post('collage_name');
                


                $result3=$this->join_model->add('education',$data3);

                if($result){
                    // $message=array('message'=>'added succesfully','class'=>'alert alert-success');
                    $this->session->set_flashdata('message','You Are  Register Successfully');
                    redirect('join/loginpage');
                }else{
                    // $message=array('message'=>'not added!!','class'=>'alert alert-danger');
                    $this->session->set_flashdata('message','not added!!');
                    redirect('join/store');
                }
                $mp=$this->join_model->insert_entry();
                $user_id=$result;
                $this->session->set_userdata('user_id', $user_id);       
              
              $this->load->view('join/registaion');
              }
              $this->load->view('products/index');
               $this->load->view('products/reg');
              
}
        }

//---------------User login--------------
public function loginpage()
          {
                $this->load->view('products/index');
                $this->load->view('products/login');
              
          }
        //--------user logout--------  
public function logindata()
          {
            // $this->load->model('join_model');
             $data=array();
             $data['email']=$_POST['email'];
             $data['phone']=$_POST['mobile'];


             
             
             $id= $this->join_model->loginCheck($data);
              if($id)
               {
                 $this->session->set_userdata('id',$id);
                 $this->session->set_flashdata('message','You Are Login Successfully');
                 return redirect('DashboardController');
               }
              else   
               {
                  $this->session->set_flashdata('message','You Are Not Login!!');
                  return redirect('join/loginpage');
               }

          }  

        
public function logout()
           {
              $this->session->unset_userdata('id');
              $this->session->set_flashdata('message','You Are Logout Successfully');
              return redirect('join/index');
           } 
          




// ---------------------Admin Page System------------------------------           
           //admin login system

public function registaion1(){
            $this->load->view('products/index1');
            $this->load->view('products/adminreg');
          } 
        //----admin store2 ------------
public function store2(){
            if($this->input->post()){
              $this->load->library('form_validation');
              $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
            //user info
            $this->form_validation->set_rules('email','Email','trim|required|valid_email'); 
            $this->form_validation->set_rules('phone', 'mobile', 'trim|required');
            
            if($this->form_validation->run() == FALSE){
                 

              $this->session->set_flashdata('message','Please Insert Right Data');
                 
                   
            }else
            {

             
             $email=$_POST['email'];
             $mobile=$_POST['phone'];
             

               
                  if($this->join_model->emailcheck('admins',$email)) 
                    {
                      $this->session->set_flashdata('message','This Email Earley Register');
                        return redirect('join/registaion1');
                    }    
             else if($this->join_model->mobilecheck('admins',$mobile)) 
                    {
                      $this->session->set_flashdata('message','This Mobile Earley Register');
                        return redirect('join/registaion1');
                    }    
                   
                        //user data
                $datat=array();

                
                $datat['email'] = $this->input->post('email');
                $datat['phone'] = $this->input->post('phone');
                


                $result=$this->join_model->add('admins',$datat);
                $admin_id=$result;
                if($result){
                  // $message=array('message'=>'added succesfully','class'=>'alert alert-success');
                  $this->session->set_flashdata('message','You Are  Register Successfully');
                  redirect('join/adminloginpage');
              }else{
                  // $message=array('message'=>'not added!!','class'=>'alert alert-danger');
                  $this->session->set_flashdata('message','not added!!');
                  redirect('join/store2');
              }
            }  
          }
          $this->load->view('products/adminlogin');
        } 
      


public function Adminloginpage()
          {
                $this->load->view('products/index1');
                $this->load->view('products/adminlogin');
              
          }
        
public function Adminlogindata()
          {
            $this->load->model('join_model');
             $data=array();
             $data['email']=$_POST['email'];
             $data['phone']=$_POST['mobile'];


             
             
             $id= $this->join_model->adminloginCheck($data);
              if($id)
               {
                 $this->session->set_userdata('id',$id);
                 $this->session->set_flashdata('message','You Are Login Successfully');
                 return redirect('DashboardController');
               }
              else   
               {
                  $this->session->set_flashdata('message','You Are Not Login!!');
                  return redirect('join/adminloginpage');
               }

          }  

public function adminlogout()
           {
              $this->session->unset_userdata('id');
              $this->session->set_flashdata('message','You Are Logout Successfully');
              return redirect('join/index1');
           } 


        //---------profile---------
public function profile()
            {
                $id=$_SESSION['id'];
                $this->load->model('join_model');
                $data=$this->join_model->profileData( $id);
                $newData=$data[0];
                 $this->load->view('products/index');
                 $this->load->view('products/profile',['data'=>$newData]);
            }
            
            
        //-------list------------    
public function list()
            {
              $this->load->model('join_model');
              $data= $this->join_model->allData();
              $this->load->view('products/index');
              $this->load->view('products/list',['data'=>$data]);
              

            }  

            //--------show-----------
public function show(){

                $this->load->model('join_model');
                $data['data']=$this->join_model->showone();
                $this->load->view('products/index');
                $this->load->view('products/show',$data);
  
               }
  //admin show 
public function show1(){

    $this->load->model('join_model');
    $data['data']=$this->join_model->showone1();
    $this->load->view('products/index');
    $this->load->view('products/product_view',$data);

   }                 
          //---------remove-------------
public function remove()
           {
            $this->load->view('products/index');
            $this->load->view('products/remove');
           }  
          //-----------delete----------- 
public function delete()
             {
                $id=$_POST['id'];
                $this->load->model('join_model');
                $data= $this->join_model->removeData($id);
                if($data)
                 {
                   $this->session->set_flashdata('message','data delete successfully');
                    return redirect('join/remove');
                 }

             }

          
public function remove1()
             {
              $this->load->view('products/index1');
              $this->load->view('products/remove1');
             }  
            //-----------delete----------- 
public function delete1()
               {
                  $id=$_POST['id'];
                  $this->load->model('join_model');
                  $data1= $this->join_model->removeData1($id);
                  if($data1)
                   {
                     $this->session->set_flashdata('message','data delete successfully');
                      return redirect('join/remove1');
                   }
  
               }
  
                         
        }
         
        

        

?>