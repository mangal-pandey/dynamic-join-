<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('attendance_model');
        $this->load->library('session');
    }

    public function index() {
 // the login data store in a session id and already feed a data user_id       
        $user_id = $_SESSION['id'];
 //  the logged-in user's ID
        
        
        $data['attendance'] = $this->attendance_model->getAttendance($user_id);
        $this->load->view('products/index');
        $this->load->view('dashboard_view', $data);
    }

    public function checkIn() {
  // the login data store in a session id and already feed a data user_id      
        $user_id =$_SESSION['id'];
 //  the logged-in user's ID
        $this->attendance_model->checkIn($user_id);
        redirect('dashboardcontroller');
    }

    public function checkOut() {
 // the login data store in a session id and already feed a data user_id
        $user_id =$_SESSION['id'];
 //  the logged-out user's ID
        $this->attendance_model->checkOut($user_id);
        redirect('dashboardcontroller');
    }
}
