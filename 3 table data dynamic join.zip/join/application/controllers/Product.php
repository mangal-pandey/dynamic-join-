<?php

class Product extends CI_controller{

public function __construct() {
    parent::__construct();
    $this->load->library('form_validation'); 
    $this->load->model('join_model');

  }
public function index(){
      $this->load->view('products/index1');
  }

public function product(){
    $this->load->view('products/index1');
    $this->load->view('products/product');
  } 
public function do_upload() {
    $config['upload_path']   = './image/';
    $config['allowed_types'] = 'gif|jpg|png';
    // $config['max_size']      = 2048; // 2MB
    // $config['max_width']     = 1024;
    // $config['max_height']    = 768;

    $this->load->library('upload', $config);

    if ($this->upload->do_upload('userfile')) {
        // File uploaded successfully
        $data = array('upload_data' => $this->upload->data());
        $this->load->view('upload_success', $data);
    } else {
        // File upload failed
        $error = array('error' => $this->upload->display_errors());
        $this->load->view('products/product', $error);
    }
}      

    
public function store(){
            if($this->input->post()){

            

              $this->load->library('form_validation');
              $config['upload_path']   = './images/';
              $config['allowed_types'] = 'gif|jpg|png';
            //   $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        
            $this->form_validation->set_rules('name','Name','trim|required');
            $this->form_validation->set_rules('des','Description','trim|required');
            $this->form_validation->set_rules('userfile','Image');
            // $this->form_validation->set_rules('other_image','Other Image');
            $this->form_validation->set_rules('short_desc','Short Desc');
            $this->form_validation->set_rules('category','Category','required');
            $this->load->library('upload', $config);

            if($this->form_validation->run() == FALSE){
                 

              $this->session->set_flashdata('message','Please Insert Right Data');
                 
                   
            }else{
                if ($this->upload->do_upload('userfile')) {
                    // File uploaded successfully
                    $data = array('upload_data' => $this->upload->data());
                    $this->load->view('upload_success', $data);
                
                $data=array();
                $data['name'] = $this->input->post('name');
                $data['des'] = $this->input->post('des');
                $data['image'] = $this->input->post('image');
                $data['other_image']=$this->input->post('other_image');
                $data['short_desc']=$this->input->post('short_desc');
                $data['category']=$this->input->post('category');

                
               
                $result=$this->join_model->add('product_detail',$data);
                }else {
                    // File upload failed
                    $error = array('error' => $this->upload->display_errors());
                    $this->load->view('products/product', $error);
                }
                $data2=array();

                $data2['product_id']=$result;
                $data2['mrp_price'] = $this->input->post('mrp_price');
                $data2['selling_price'] = $this->input->post('selling_price');
                


                $result2=$this->join_model->add('product_price',$data2);
                
                $data3['product_id']=$result;
                $data3['qty_available']=$this->input->post('qty_available');

                $result3=$this->join_model->add('product_stock',$data3);

                if($result){
                    // $message=array('message'=>'added succesfully','class'=>'alert alert-success');
                    $this->session->set_flashdata('message','Item add ');
                    redirect('join/admin');
                }else{
                    // $message=array('message'=>'not added!!','class'=>'alert alert-danger');
                    $this->session->set_flashdata('message','not added!!');
                    redirect('join/store');
                }
                $mp=$this->join_model->insert_entry1();
                $product_id=$result;
                $this->session->set_userdata('product_id', $product_id);       
              
              $this->load->view('join/product');
              }
              
              $this->load->view('products/index');
               $this->load->view('products/product');
              
}
    }

      
// public function do_upload()
//         {

//             $this->load->library('upload');
//             $config['file_name']=time();
//             $config['upload_path'] = './images/';
//             $config['allowed_types'] = 'gif|jpg|png';
//             $config['max_size'] = 2000;
//             $config['max_width'] = 1500;
//             $config['max_height'] = 1500;
//              $this->upload->initialize($config);


//                 if ( ! $this->upload->do_upload('userfile'))
//                 {
//                         $error = array('error' => $this->upload->display_errors());

//                         $this->load->view('product', $error);
//                 }
//                 else
//                 {
//                     $mp=$this->upload->do_upload('image');
//                     $imagedata= $this->upload->data();
//                     $imagename=$imagedata['file_name'];
//                 }
//         }
  
}


?>