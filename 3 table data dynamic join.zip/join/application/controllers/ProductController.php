<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('ProductModel');
    }

    public function index() {
        $this->load->view('product_form');
    }

    public function add_product() {
        $config['upload_path']   = './images/';
        $config['allowed_types'] = 'gif|jpg|png';
        // $config['max_size']      = 2048; // 2MB
        // $config['max_width']     = 1024;
        // $config['max_height']    = 768;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('userfile')) {
            // File uploaded successfully
            $upload_data = $this->upload->data();

            // Insert product details
            $data = array(
                'name' => $this->input->post('name'),
                'des' => $this->input->post('des'),
                'image' => $upload_data['file_name'],
                'other_image' => $upload_data['file_name1'],
                'short_desc'=>$this->input->post('short_desc'),
                'category'=>$this->input->post('category')
            );

            $product_id = $this->ProductModel->insert_product($data);

            // Insert product price
            $price_data = array(
                'product_id' => $product_id,
                
                'mrp_price'=>$this->input->post('mrp_price'),
                'selling_price'=>$this->input->post('selling_price')
            );

            $price_id = $this->ProductModel->insert_price($price_data);

            // Insert product stock
            $stock_data = array(
                'product_id' => $product_id,
                'qty_available' => $this->input->post('qty_available')
            );

            $stock_id = $this->ProductModel->insert_stock($stock_data);

            if ($product_id && $price_id && $stock_id) {
                redirect('productcontroller/view_product/' . $product_id);
            } else {
                echo 'Error inserting product into database.';
            }
        } else {
            // File upload failed
            $error = array('error' => $this->upload->display_errors());
            $this->load->view('product_form', $error);
        }
    }

    public function view_product($product_id) {
        // Fetch product details, price, and stock from the database based on $product_id
        $data['product'] = $this->ProductModel->get_product_details($product_id);
        // $this->load->view('product_details', $data);
        $this->load->view('productv',$data);
    }
}
